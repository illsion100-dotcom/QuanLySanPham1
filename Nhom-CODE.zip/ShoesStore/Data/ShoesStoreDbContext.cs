using Microsoft.EntityFrameworkCore;
using ShoesStore.Models;

namespace ShoesStore.Data
{
    public class ShoesStoreDbContext : DbContext
    {
        public ShoesStoreDbContext(DbContextOptions<ShoesStoreDbContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; } = default!;

        public DbSet<Product> Products { get; set; } = default!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("Categories");
                entity.HasKey(c => c.CategoryId);
                entity.Property(c => c.CategoryName).IsRequired().HasMaxLength(100);
                entity.Property(c => c.Description).HasMaxLength(500);
                entity.HasIndex(c => c.CategoryName).IsUnique();
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Products", table =>
                {
                    table.HasCheckConstraint("CK_Products_Price", "[Price] >= 0");
                    table.HasCheckConstraint("CK_Products_Quantity", "[Quantity] >= 0");
                    table.HasCheckConstraint("CK_Products_Size", "[Size] BETWEEN 20 AND 50");
                });
                entity.HasKey(p => p.ProductId);
                entity.Property(p => p.ProductName).IsRequired().HasMaxLength(150);
                entity.Property(p => p.Brand).IsRequired().HasMaxLength(100);
                entity.Property(p => p.Color).HasMaxLength(50);
                entity.Property(p => p.Price).HasPrecision(18, 2);
                entity.Property(p => p.ImportDate).HasColumnType("date");
                entity.Property(p => p.ImageUrl).HasMaxLength(255);
                entity.Property(p => p.Description).HasMaxLength(1000);
                entity.HasIndex(p => p.ProductName);

                entity.HasOne(p => p.Category)
                    .WithMany(c => c.Products)
                    .HasForeignKey(p => p.CategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            SeedData(modelBuilder);
        }

        private static void SeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = 1, CategoryName = "Giày thể thao", Description = "Giày chạy bộ, giày tập gym, sneaker dạo phố cho nam và nữ" },
                new Category { CategoryId = 2, CategoryName = "Giày da nam", Description = "Giày tây, giày lười da thật phong cách công sở lịch lãm" },
                new Category { CategoryId = 3, CategoryName = "Giày cao gót", Description = "Giày cao gót nữ từ 5cm đến 9cm cho công sở và dự tiệc" },
                new Category { CategoryId = 4, CategoryName = "Dép - Sandal", Description = "Dép quai ngang, sandal quai hậu đi chơi, đi biển" },
                new Category { CategoryId = 5, CategoryName = "Giày trẻ em", Description = "Giày dép êm nhẹ, an toàn cho bé từ 3 đến 12 tuổi" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { ProductId = 1, ProductName = "Giày chạy bộ Nike Air Zoom Pegasus 41", Brand = "Nike", Size = 42, Color = "Đen trắng", Price = 3290000m, Quantity = 25, ImportDate = new DateTime(2026, 9, 5), ImageUrl = null, Description = "Đệm ReactX êm ái, phù hợp chạy bộ đường dài và tập luyện hằng ngày.", CategoryId = 1 },
                new Product { ProductId = 2, ProductName = "Giày thể thao Adidas Ultraboost Light", Brand = "Adidas", Size = 41, Color = "Trắng", Price = 4500000m, Quantity = 18, ImportDate = new DateTime(2026, 9, 12), ImageUrl = null, Description = "Đế Boost hoàn trả năng lượng, thân giày Primeknit thoáng khí.", CategoryId = 1 },
                new Product { ProductId = 3, ProductName = "Giày Biti's Hunter X Festive", Brand = "Biti's", Size = 40, Color = "Xanh navy", Price = 1150000m, Quantity = 40, ImportDate = new DateTime(2026, 9, 20), ImageUrl = null, Description = "Thương hiệu Việt, đế LiteFlex siêu nhẹ, giá hợp lý cho sinh viên.", CategoryId = 1 },
                new Product { ProductId = 4, ProductName = "Giày tây da bò Oxford cổ điển", Brand = "Pierre Cardin", Size = 41, Color = "Đen", Price = 2450000m, Quantity = 12, ImportDate = new DateTime(2026, 9, 25), ImageUrl = null, Description = "Da bò thật nguyên tấm, kiểu buộc dây Oxford lịch lãm cho công sở.", CategoryId = 2 },
                new Product { ProductId = 5, ProductName = "Giày lười da nam Loafer", Brand = "Clarks", Size = 42, Color = "Nâu bò", Price = 1890000m, Quantity = 15, ImportDate = new DateTime(2026, 10, 2), ImageUrl = null, Description = "Thiết kế không dây tiện lợi, lót da mềm, đi cả ngày không đau chân.", CategoryId = 2 },
                new Product { ProductId = 6, ProductName = "Giày cao gót mũi nhọn 7cm", Brand = "Vascara", Size = 36, Color = "Kem", Price = 690000m, Quantity = 30, ImportDate = new DateTime(2026, 10, 8), ImageUrl = null, Description = "Gót nhọn 7cm thanh lịch, da tổng hợp cao cấp, phù hợp đi làm.", CategoryId = 3 },
                new Product { ProductId = 7, ProductName = "Giày cao gót quai mảnh 9cm", Brand = "Đông Hải", Size = 37, Color = "Đỏ đô", Price = 850000m, Quantity = 8, ImportDate = new DateTime(2026, 10, 15), ImageUrl = null, Description = "Quai mảnh tôn dáng, gót 9cm sang trọng dành cho các buổi tiệc.", CategoryId = 3 },
                new Product { ProductId = 8, ProductName = "Dép quai ngang Adidas Adilette", Brand = "Adidas", Size = 42, Color = "Đen", Price = 750000m, Quantity = 50, ImportDate = new DateTime(2026, 10, 20), ImageUrl = null, Description = "Đế cao su đúc nguyên khối, quai ngang ôm chân, chống trơn trượt.", CategoryId = 4 },
                new Product { ProductId = 9, ProductName = "Sandal Biti's Hunter quai dù", Brand = "Biti's", Size = 39, Color = "Xám", Price = 520000m, Quantity = 35, ImportDate = new DateTime(2026, 10, 28), ImageUrl = null, Description = "Quai dù bền chắc, khóa dán điều chỉnh, thích hợp đi phượt và du lịch.", CategoryId = 4 },
                new Product { ProductId = 10, ProductName = "Giày thể thao trẻ em đèn LED", Brand = "Biti's", Size = 32, Color = "Hồng", Price = 450000m, Quantity = 6, ImportDate = new DateTime(2026, 11, 3), ImageUrl = null, Description = "Đế phát sáng khi bước đi, quai dán tiện lợi cho bé tự mang.", CategoryId = 5 }
            );
        }
    }
}
