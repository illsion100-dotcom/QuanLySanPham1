/* =====================================================================
   SCRIPT TẠO CƠ SỞ DỮ LIỆU: ShoesStoreDb
   Đề tài : Ứng dụng Web Quản lý Cửa hàng Bán Giày dép (Shoes Store)
   CSDL   : SQL Server 2019+/ SQL Server Express / LocalDB
   Ghi chú: Cấu trúc bảng trùng khớp 100% với model Entity Framework Core
            (Models/Category.cs, Models/Product.cs, Data/ShoesStoreDbContext.cs).
            Chỉ dùng MỘT trong hai cách: chạy script này HOẶC chạy
            Add-Migration + Update-Database. Không chạy cả hai.
   ===================================================================== */

USE master;
GO

IF DB_ID(N'ShoesStoreDb') IS NULL
BEGIN
    CREATE DATABASE ShoesStoreDb;
END
GO

USE ShoesStoreDb;
GO

/* ---------- Xóa bảng cũ (nếu có) theo thứ tự bảng con -> bảng cha ---------- */
IF OBJECT_ID(N'dbo.Products', N'U') IS NOT NULL
    DROP TABLE dbo.Products;
GO

IF OBJECT_ID(N'dbo.Categories', N'U') IS NOT NULL
    DROP TABLE dbo.Categories;
GO

/* ---------- Bảng 1: Categories (Danh mục / Loại giày) ---------- */
CREATE TABLE dbo.Categories
(
    CategoryId   INT IDENTITY(1,1) NOT NULL,
    CategoryName NVARCHAR(100)     NOT NULL,
    Description  NVARCHAR(500)     NULL,
    CONSTRAINT PK_Categories PRIMARY KEY (CategoryId)
);
GO

CREATE UNIQUE INDEX IX_Categories_CategoryName ON dbo.Categories (CategoryName);
GO

/* ---------- Bảng 2: Products (Sản phẩm giày) ---------- */
CREATE TABLE dbo.Products
(
    ProductId   INT IDENTITY(1,1) NOT NULL,
    ProductName NVARCHAR(150)     NOT NULL,
    Brand       NVARCHAR(100)     NOT NULL,
    Size        INT               NOT NULL,
    Color       NVARCHAR(50)      NULL,
    Price       DECIMAL(18,2)     NOT NULL,
    Quantity    INT               NOT NULL,
    ImportDate  DATE              NOT NULL,
    ImageUrl    NVARCHAR(255)     NULL,
    Description NVARCHAR(1000)    NULL,
    CategoryId  INT               NOT NULL,
    CONSTRAINT PK_Products PRIMARY KEY (ProductId),
    CONSTRAINT FK_Products_Categories_CategoryId FOREIGN KEY (CategoryId)
        REFERENCES dbo.Categories (CategoryId) ON DELETE NO ACTION,
    CONSTRAINT CK_Products_Price    CHECK ([Price] >= 0),
    CONSTRAINT CK_Products_Quantity CHECK ([Quantity] >= 0),
    CONSTRAINT CK_Products_Size     CHECK ([Size] BETWEEN 20 AND 50)
);
GO

CREATE INDEX IX_Products_CategoryId  ON dbo.Products (CategoryId);
CREATE INDEX IX_Products_ProductName ON dbo.Products (ProductName);
GO

/* ---------- Dữ liệu mẫu: 5 danh mục ---------- */
SET IDENTITY_INSERT dbo.Categories ON;

INSERT INTO dbo.Categories (CategoryId, CategoryName, Description) VALUES
(1, N'Giày thể thao', N'Giày chạy bộ, giày tập gym, sneaker dạo phố cho nam và nữ'),
(2, N'Giày da nam',   N'Giày tây, giày lười da thật phong cách công sở lịch lãm'),
(3, N'Giày cao gót',  N'Giày cao gót nữ từ 5cm đến 9cm cho công sở và dự tiệc'),
(4, N'Dép - Sandal',  N'Dép quai ngang, sandal quai hậu đi chơi, đi biển'),
(5, N'Giày trẻ em',   N'Giày dép êm nhẹ, an toàn cho bé từ 3 đến 12 tuổi');

SET IDENTITY_INSERT dbo.Categories OFF;
GO

/* ---------- Dữ liệu mẫu: 10 sản phẩm giày ---------- */
SET IDENTITY_INSERT dbo.Products ON;

INSERT INTO dbo.Products (ProductId, ProductName, Brand, Size, Color, Price, Quantity, ImportDate, ImageUrl, Description, CategoryId) VALUES
(1,  N'Giày chạy bộ Nike Air Zoom Pegasus 41', N'Nike',          42, N'Đen trắng', 3290000, 25, '2026-09-05', NULL, N'Đệm ReactX êm ái, phù hợp chạy bộ đường dài và tập luyện hằng ngày.', 1),
(2,  N'Giày thể thao Adidas Ultraboost Light', N'Adidas',        41, N'Trắng',     4500000, 18, '2026-09-12', NULL, N'Đế Boost hoàn trả năng lượng, thân giày Primeknit thoáng khí.', 1),
(3,  N'Giày Biti''s Hunter X Festive',         N'Biti''s',       40, N'Xanh navy', 1150000, 40, '2026-09-20', NULL, N'Thương hiệu Việt, đế LiteFlex siêu nhẹ, giá hợp lý cho sinh viên.', 1),
(4,  N'Giày tây da bò Oxford cổ điển',         N'Pierre Cardin', 41, N'Đen',       2450000, 12, '2026-09-25', NULL, N'Da bò thật nguyên tấm, kiểu buộc dây Oxford lịch lãm cho công sở.', 2),
(5,  N'Giày lười da nam Loafer',               N'Clarks',        42, N'Nâu bò',    1890000, 15, '2026-10-02', NULL, N'Thiết kế không dây tiện lợi, lót da mềm, đi cả ngày không đau chân.', 2),
(6,  N'Giày cao gót mũi nhọn 7cm',             N'Vascara',       36, N'Kem',        690000, 30, '2026-10-08', NULL, N'Gót nhọn 7cm thanh lịch, da tổng hợp cao cấp, phù hợp đi làm.', 3),
(7,  N'Giày cao gót quai mảnh 9cm',            N'Đông Hải',      37, N'Đỏ đô',      850000,  8, '2026-10-15', NULL, N'Quai mảnh tôn dáng, gót 9cm sang trọng dành cho các buổi tiệc.', 3),
(8,  N'Dép quai ngang Adidas Adilette',        N'Adidas',        42, N'Đen',        750000, 50, '2026-10-20', NULL, N'Đế cao su đúc nguyên khối, quai ngang ôm chân, chống trơn trượt.', 4),
(9,  N'Sandal Biti''s Hunter quai dù',         N'Biti''s',       39, N'Xám',        520000, 35, '2026-10-28', NULL, N'Quai dù bền chắc, khóa dán điều chỉnh, thích hợp đi phượt và du lịch.', 4),
(10, N'Giày thể thao trẻ em đèn LED',          N'Biti''s',       32, N'Hồng',       450000,  6, '2026-11-03', NULL, N'Đế phát sáng khi bước đi, quai dán tiện lợi cho bé tự mang.', 5);

SET IDENTITY_INSERT dbo.Products OFF;
GO

/* ---------- Kiểm tra dữ liệu ---------- */
SELECT p.ProductId, p.ProductName, p.Brand, p.Size, p.Price, p.Quantity, c.CategoryName
FROM dbo.Products p
INNER JOIN dbo.Categories c ON c.CategoryId = p.CategoryId
ORDER BY p.ProductId;
GO

/* ---------- Truy vấn thống kê tương đương trang Thống kê ---------- */
SELECT c.CategoryName                             AS N'Danh mục',
       COUNT(p.ProductId)                         AS N'Số mẫu sản phẩm',
       ISNULL(SUM(p.Quantity), 0)                 AS N'Tổng số lượng tồn',
       ISNULL(SUM(p.Price * p.Quantity), 0)       AS N'Giá trị tồn kho'
FROM dbo.Categories c
LEFT JOIN dbo.Products p ON p.CategoryId = c.CategoryId
GROUP BY c.CategoryId, c.CategoryName
ORDER BY COUNT(p.ProductId) DESC, c.CategoryName;
GO
