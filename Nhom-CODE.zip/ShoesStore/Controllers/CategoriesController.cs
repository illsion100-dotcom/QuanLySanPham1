using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoesStore.Data;
using ShoesStore.Models;

namespace ShoesStore.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly ShoesStoreDbContext _context;

        public CategoriesController(ShoesStoreDbContext context)
        {
            _context = context;
        }

        // GET: Categories
        // GET: Categories?searchString=giày
        public async Task<IActionResult> Index(string? searchString)
        {
            IQueryable<Category> query = _context.Categories
                .Include(c => c.Products)
                .AsNoTracking();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                string keyword = searchString.Trim();
                query = query.Where(c => c.CategoryName.Contains(keyword));
            }

            List<Category> categories = await query
                .OrderBy(c => c.CategoryId)
                .ToListAsync();

            ViewData["SearchString"] = searchString;
            return View(categories);
        }

        // GET: Categories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Category? category = await _context.Categories
                .Include(c => c.Products)
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // GET: Categories/Create
        public IActionResult Create()
        {
            return View(new Category());
        }

        // POST: Categories/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CategoryName,Description")] Category category)
        {
            await ValidateUniqueNameAsync(category);

            if (ModelState.IsValid)
            {
                category.CategoryName = category.CategoryName.Trim();
                _context.Add(category);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Đã thêm danh mục \"{category.CategoryName}\" thành công.";
                return RedirectToAction(nameof(Index));
            }

            return View(category);
        }

        // GET: Categories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Category? category = await _context.Categories.FindAsync(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // POST: Categories/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CategoryId,CategoryName,Description")] Category category)
        {
            if (id != category.CategoryId)
            {
                return NotFound();
            }

            await ValidateUniqueNameAsync(category);

            if (ModelState.IsValid)
            {
                category.CategoryName = category.CategoryName.Trim();

                try
                {
                    _context.Update(category);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await CategoryExistsAsync(category.CategoryId))
                    {
                        return NotFound();
                    }

                    throw;
                }

                TempData["SuccessMessage"] = $"Đã cập nhật danh mục \"{category.CategoryName}\" thành công.";
                return RedirectToAction(nameof(Index));
            }

            return View(category);
        }

        // GET: Categories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Category? category = await _context.Categories
                .Include(c => c.Products)
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // POST: Categories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            Category? category = await _context.Categories.FindAsync(id);

            if (category == null)
            {
                TempData["ErrorMessage"] = "Danh mục không tồn tại hoặc đã bị xóa trước đó.";
                return RedirectToAction(nameof(Index));
            }

            bool hasProducts = await _context.Products.AnyAsync(p => p.CategoryId == id);

            if (hasProducts)
            {
                TempData["ErrorMessage"] = $"Không thể xóa danh mục \"{category.CategoryName}\" vì vẫn còn sản phẩm thuộc danh mục này. Hãy chuyển hoặc xóa các sản phẩm trước.";
                return RedirectToAction(nameof(Delete), new { id });
            }

            string categoryName = category.CategoryName;
            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"Đã xóa danh mục \"{categoryName}\".";
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> CategoryExistsAsync(int id)
        {
            return await _context.Categories.AnyAsync(e => e.CategoryId == id);
        }

        private async Task ValidateUniqueNameAsync(Category category)
        {
            if (string.IsNullOrWhiteSpace(category.CategoryName))
            {
                return;
            }

            string name = category.CategoryName.Trim();
            bool duplicated = await _context.Categories.AnyAsync(c =>
                c.CategoryName == name &&
                c.CategoryId != category.CategoryId);

            if (duplicated)
            {
                ModelState.AddModelError(nameof(Category.CategoryName), "Tên danh mục này đã tồn tại.");
            }
        }
    }
}
