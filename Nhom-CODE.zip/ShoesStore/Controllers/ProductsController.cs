using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ShoesStore.Data;
using ShoesStore.Models;
using ShoesStore.Models.ViewModels;

namespace ShoesStore.Controllers
{
    public class ProductsController : Controller
    {
        private const int PageSize = 5;
        private const long MaxImageSizeInBytes = 2 * 1024 * 1024;
        private const string ProductImageFolder = "/images/products/";
        private static readonly string[] AllowedImageExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".webp" };

        private readonly ShoesStoreDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public ProductsController(ShoesStoreDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // GET: Products
        // GET: Products?searchString=nike&categoryId=1&minPrice=500000&maxPrice=5000000&sortOrder=price_asc&pageNumber=2
        public async Task<IActionResult> Index(string? searchString, int? categoryId, decimal? minPrice, decimal? maxPrice, string? sortOrder, int? pageNumber)
        {
            IQueryable<Product> query = _context.Products
                .Include(p => p.Category)
                .AsNoTracking();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                string keyword = searchString.Trim();
                query = query.Where(p => p.ProductName.Contains(keyword) || p.Brand.Contains(keyword));
            }

            if (categoryId.HasValue && categoryId.Value > 0)
            {
                query = query.Where(p => p.CategoryId == categoryId.Value);
            }

            if (minPrice.HasValue && maxPrice.HasValue && minPrice.Value > maxPrice.Value)
            {
                decimal temp = minPrice.Value;
                minPrice = maxPrice;
                maxPrice = temp;
            }

            if (minPrice.HasValue)
            {
                query = query.Where(p => p.Price >= minPrice.Value);
            }

            if (maxPrice.HasValue)
            {
                query = query.Where(p => p.Price <= maxPrice.Value);
            }

            query = sortOrder switch
            {
                "name_asc" => query.OrderBy(p => p.ProductName),
                "name_desc" => query.OrderByDescending(p => p.ProductName),
                "price_asc" => query.OrderBy(p => p.Price).ThenBy(p => p.ProductName),
                "price_desc" => query.OrderByDescending(p => p.Price).ThenBy(p => p.ProductName),
                "quantity_asc" => query.OrderBy(p => p.Quantity).ThenBy(p => p.ProductName),
                "date_desc" => query.OrderByDescending(p => p.ImportDate).ThenByDescending(p => p.ProductId),
                _ => query.OrderByDescending(p => p.ProductId)
            };

            PaginatedList<Product> products = await PaginatedList<Product>.CreateAsync(query, pageNumber ?? 1, PageSize);

            List<Category> categories = await _context.Categories
                .AsNoTracking()
                .OrderBy(c => c.CategoryName)
                .ToListAsync();

            List<SelectListItem> sortItems = new List<SelectListItem>
            {
                new SelectListItem { Value = "", Text = "Mới thêm gần đây" },
                new SelectListItem { Value = "name_asc", Text = "Tên A → Z" },
                new SelectListItem { Value = "name_desc", Text = "Tên Z → A" },
                new SelectListItem { Value = "price_asc", Text = "Giá tăng dần" },
                new SelectListItem { Value = "price_desc", Text = "Giá giảm dần" },
                new SelectListItem { Value = "quantity_asc", Text = "Tồn kho ít nhất" },
                new SelectListItem { Value = "date_desc", Text = "Ngày nhập mới nhất" }
            };

            ProductIndexViewModel viewModel = new ProductIndexViewModel
            {
                Products = products,
                SearchString = searchString,
                CategoryId = categoryId,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                SortOrder = sortOrder,
                Categories = new SelectList(categories, "CategoryId", "CategoryName", categoryId),
                SortOptions = new SelectList(sortItems, "Value", "Text", sortOrder ?? "")
            };

            return View(viewModel);
        }

        // GET: Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Product? product = await _context.Products
                .Include(p => p.Category)
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.ProductId == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
        public async Task<IActionResult> Create()
        {
            await PopulateCategoriesDropDownListAsync(null);

            Product product = new Product
            {
                ImportDate = DateTime.Today,
                Quantity = 0
            };

            return View(product);
        }

        // POST: Products/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductName,Brand,Size,Color,Price,Quantity,ImportDate,Description,CategoryId,ImageFile")] Product product)
        {
            await ValidateBusinessRulesAsync(product);
            ValidateImageFile(product.ImageFile);

            if (ModelState.IsValid)
            {
                if (product.ImageFile != null)
                {
                    product.ImageUrl = await SaveImageAsync(product.ImageFile);
                }

                product.ProductName = product.ProductName.Trim();
                product.Brand = product.Brand.Trim();

                _context.Add(product);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Đã thêm sản phẩm \"{product.ProductName}\" thành công.";
                return RedirectToAction(nameof(Index));
            }

            await PopulateCategoriesDropDownListAsync(product.CategoryId);
            return View(product);
        }

        // GET: Products/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Product? product = await _context.Products.FindAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            await PopulateCategoriesDropDownListAsync(product.CategoryId);
            return View(product);
        }

        // POST: Products/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductId,ProductName,Brand,Size,Color,Price,Quantity,ImportDate,Description,CategoryId,ImageFile")] Product product)
        {
            if (id != product.ProductId)
            {
                return NotFound();
            }

            Product? existingProduct = await _context.Products
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.ProductId == id);

            if (existingProduct == null)
            {
                return NotFound();
            }

            product.ImageUrl = existingProduct.ImageUrl;

            await ValidateBusinessRulesAsync(product);
            ValidateImageFile(product.ImageFile);

            if (ModelState.IsValid)
            {
                string? oldImageUrl = existingProduct.ImageUrl;

                if (product.ImageFile != null)
                {
                    product.ImageUrl = await SaveImageAsync(product.ImageFile);
                }

                product.ProductName = product.ProductName.Trim();
                product.Brand = product.Brand.Trim();

                try
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await ProductExistsAsync(product.ProductId))
                    {
                        return NotFound();
                    }

                    throw;
                }

                if (product.ImageFile != null && oldImageUrl != product.ImageUrl)
                {
                    DeleteImageFile(oldImageUrl);
                }

                TempData["SuccessMessage"] = $"Đã cập nhật sản phẩm \"{product.ProductName}\" thành công.";
                return RedirectToAction(nameof(Index));
            }

            await PopulateCategoriesDropDownListAsync(product.CategoryId);
            return View(product);
        }

        // GET: Products/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Product? product = await _context.Products
                .Include(p => p.Category)
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.ProductId == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            Product? product = await _context.Products.FindAsync(id);

            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại hoặc đã bị xóa trước đó.";
                return RedirectToAction(nameof(Index));
            }

            string productName = product.ProductName;
            string? imageUrl = product.ImageUrl;

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            DeleteImageFile(imageUrl);

            TempData["SuccessMessage"] = $"Đã xóa sản phẩm \"{productName}\".";
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> ProductExistsAsync(int id)
        {
            return await _context.Products.AnyAsync(e => e.ProductId == id);
        }

        private async Task PopulateCategoriesDropDownListAsync(object? selectedCategory)
        {
            List<Category> categories = await _context.Categories
                .AsNoTracking()
                .OrderBy(c => c.CategoryName)
                .ToListAsync();

            ViewData["CategoryList"] = new SelectList(categories, "CategoryId", "CategoryName", selectedCategory);
        }

        private async Task ValidateBusinessRulesAsync(Product product)
        {
            if (product.ImportDate.Date > DateTime.Today)
            {
                ModelState.AddModelError(nameof(Product.ImportDate), "Ngày nhập không được lớn hơn ngày hiện tại.");
            }

            if (product.CategoryId > 0)
            {
                bool categoryExists = await _context.Categories.AnyAsync(c => c.CategoryId == product.CategoryId);
                if (!categoryExists)
                {
                    ModelState.AddModelError(nameof(Product.CategoryId), "Danh mục đã chọn không tồn tại.");
                }
            }

            if (!string.IsNullOrWhiteSpace(product.ProductName))
            {
                string name = product.ProductName.Trim();
                bool duplicated = await _context.Products.AnyAsync(p =>
                    p.ProductName == name &&
                    p.Size == product.Size &&
                    p.ProductId != product.ProductId);

                if (duplicated)
                {
                    ModelState.AddModelError(nameof(Product.ProductName), "Đã có sản phẩm cùng tên và cùng kích cỡ trong cửa hàng.");
                }
            }
        }

        private void ValidateImageFile(IFormFile? imageFile)
        {
            if (imageFile == null)
            {
                return;
            }

            string extension = Path.GetExtension(imageFile.FileName).ToLowerInvariant();

            if (!AllowedImageExtensions.Contains(extension))
            {
                ModelState.AddModelError(nameof(Product.ImageFile), "Chỉ chấp nhận ảnh có định dạng .jpg, .jpeg, .png, .gif hoặc .webp.");
            }

            if (imageFile.Length > MaxImageSizeInBytes)
            {
                ModelState.AddModelError(nameof(Product.ImageFile), "Dung lượng ảnh tối đa là 2 MB.");
            }

            if (imageFile.Length == 0)
            {
                ModelState.AddModelError(nameof(Product.ImageFile), "File ảnh rỗng, vui lòng chọn file khác.");
            }
        }

        private async Task<string> SaveImageAsync(IFormFile imageFile)
        {
            string uploadFolder = Path.Combine(_environment.WebRootPath, "images", "products");

            if (!Directory.Exists(uploadFolder))
            {
                Directory.CreateDirectory(uploadFolder);
            }

            string extension = Path.GetExtension(imageFile.FileName).ToLowerInvariant();
            string fileName = $"{Guid.NewGuid():N}{extension}";
            string filePath = Path.Combine(uploadFolder, fileName);

            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                await imageFile.CopyToAsync(stream);
            }

            return ProductImageFolder + fileName;
        }

        private void DeleteImageFile(string? imageUrl)
        {
            if (string.IsNullOrWhiteSpace(imageUrl) || !imageUrl.StartsWith(ProductImageFolder, StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            string fileName = Path.GetFileName(imageUrl);
            string filePath = Path.Combine(_environment.WebRootPath, "images", "products", fileName);

            if (System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
            }
        }
    }
}
