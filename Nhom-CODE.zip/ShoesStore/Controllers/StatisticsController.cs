using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoesStore.Data;
using ShoesStore.Models.ViewModels;

namespace ShoesStore.Controllers
{
    public class StatisticsController : Controller
    {
        private const int LowStockThreshold = 10;

        private readonly ShoesStoreDbContext _context;

        public StatisticsController(ShoesStoreDbContext context)
        {
            _context = context;
        }

        // GET: Statistics
        public async Task<IActionResult> Index()
        {
            int totalProducts = await _context.Products.CountAsync();
            int totalCategories = await _context.Categories.CountAsync();
            int totalQuantity = await _context.Products.SumAsync(p => p.Quantity);
            decimal totalInventoryValue = await _context.Products.SumAsync(p => p.Price * p.Quantity);
            decimal averagePrice = totalProducts > 0
                ? await _context.Products.AverageAsync(p => p.Price)
                : 0;

            List<CategoryStatisticViewModel> categoryStatistics = await _context.Categories
                .AsNoTracking()
                .Select(c => new CategoryStatisticViewModel
                {
                    CategoryId = c.CategoryId,
                    CategoryName = c.CategoryName,
                    ProductCount = c.Products.Count(),
                    TotalQuantity = c.Products.Sum(p => (int?)p.Quantity) ?? 0,
                    TotalValue = c.Products.Sum(p => (decimal?)(p.Price * p.Quantity)) ?? 0
                })
                .OrderByDescending(s => s.ProductCount)
                .ThenBy(s => s.CategoryName)
                .ToListAsync();

            foreach (CategoryStatisticViewModel item in categoryStatistics)
            {
                item.ValuePercent = totalInventoryValue > 0
                    ? Math.Round((double)(item.TotalValue / totalInventoryValue) * 100, 1)
                    : 0;
            }

            List<Models.Product> lowStockProducts = await _context.Products
                .Include(p => p.Category)
                .AsNoTracking()
                .Where(p => p.Quantity < LowStockThreshold)
                .OrderBy(p => p.Quantity)
                .ToListAsync();

            StatisticsViewModel viewModel = new StatisticsViewModel
            {
                TotalProducts = totalProducts,
                TotalCategories = totalCategories,
                TotalQuantity = totalQuantity,
                TotalInventoryValue = totalInventoryValue,
                AveragePrice = averagePrice,
                LowStockThreshold = LowStockThreshold,
                CategoryStatistics = categoryStatistics,
                LowStockProducts = lowStockProducts
            };

            return View(viewModel);
        }
    }
}
