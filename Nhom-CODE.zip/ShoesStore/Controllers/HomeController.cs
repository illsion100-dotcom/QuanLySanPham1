using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoesStore.Data;
using ShoesStore.Models;
using ShoesStore.Models.ViewModels;

namespace ShoesStore.Controllers
{
    public class HomeController : Controller
    {
        private readonly ShoesStoreDbContext _context;

        public HomeController(ShoesStoreDbContext context)
        {
            _context = context;
        }

        // GET: / hoặc /Home/Index
        public async Task<IActionResult> Index()
        {
            HomeViewModel viewModel = new HomeViewModel
            {
                TotalProducts = await _context.Products.CountAsync(),
                TotalCategories = await _context.Categories.CountAsync(),
                TotalQuantity = await _context.Products.SumAsync(p => p.Quantity),
                TotalInventoryValue = await _context.Products.SumAsync(p => p.Price * p.Quantity),
                LatestProducts = await _context.Products
                    .Include(p => p.Category)
                    .AsNoTracking()
                    .OrderByDescending(p => p.ImportDate)
                    .ThenByDescending(p => p.ProductId)
                    .Take(4)
                    .ToListAsync()
            };

            return View(viewModel);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
