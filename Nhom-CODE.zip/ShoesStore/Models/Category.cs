using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShoesStore.Models
{
    [Table("Categories")]
    public class Category
    {
        [Key]
        [Display(Name = "Mã danh mục")]
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "Tên danh mục không được để trống.")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Tên danh mục phải có từ {2} đến {1} ký tự.")]
        [Display(Name = "Tên danh mục")]
        public string CategoryName { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "Mô tả không được vượt quá {1} ký tự.")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Mô tả")]
        public string? Description { get; set; }

        [Display(Name = "Danh sách sản phẩm")]
        public ICollection<Product> Products { get; set; } = new List<Product>();
    }
}
