using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace ShoesStore.Models
{
    [Table("Products")]
    public class Product
    {
        [Key]
        [Display(Name = "Mã sản phẩm")]
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Tên giày không được để trống.")]
        [StringLength(150, MinimumLength = 3, ErrorMessage = "Tên giày phải có từ {2} đến {1} ký tự.")]
        [Display(Name = "Tên giày")]
        public string ProductName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Thương hiệu không được để trống.")]
        [StringLength(100, ErrorMessage = "Thương hiệu không được vượt quá {1} ký tự.")]
        [Display(Name = "Thương hiệu")]
        public string Brand { get; set; } = string.Empty;

        [Required(ErrorMessage = "Kích cỡ không được để trống.")]
        [Range(20, 50, ErrorMessage = "Kích cỡ phải nằm trong khoảng từ {1} đến {2}.")]
        [Display(Name = "Kích cỡ (size)")]
        public int Size { get; set; }

        [StringLength(50, ErrorMessage = "Màu sắc không được vượt quá {1} ký tự.")]
        [Display(Name = "Màu sắc")]
        public string? Color { get; set; }

        [Required(ErrorMessage = "Giá bán không được để trống.")]
        [Range(1000, 100000000, ErrorMessage = "Giá bán phải từ 1.000 đ đến 100.000.000 đ.")]
        [Column(TypeName = "decimal(18,2)")]
        [DisplayFormat(DataFormatString = "{0:N0} đ")]
        [Display(Name = "Giá bán")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Số lượng tồn không được để trống.")]
        [Range(0, 100000, ErrorMessage = "Số lượng tồn phải từ {1} đến {2}.")]
        [Display(Name = "Số lượng tồn")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "Ngày nhập không được để trống.")]
        [DataType(DataType.Date)]
        [Column(TypeName = "date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Ngày nhập")]
        public DateTime ImportDate { get; set; } = DateTime.Today;

        [StringLength(255)]
        [Display(Name = "Ảnh sản phẩm")]
        public string? ImageUrl { get; set; }

        [StringLength(1000, ErrorMessage = "Mô tả không được vượt quá {1} ký tự.")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Mô tả")]
        public string? Description { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn danh mục.")]
        [Range(1, int.MaxValue, ErrorMessage = "Vui lòng chọn danh mục.")]
        [Display(Name = "Danh mục")]
        public int CategoryId { get; set; }

        [ValidateNever]
        [Display(Name = "Danh mục")]
        public Category? Category { get; set; }

        [NotMapped]
        [Display(Name = "Chọn ảnh")]
        public IFormFile? ImageFile { get; set; }

        [NotMapped]
        [DisplayFormat(DataFormatString = "{0:N0} đ")]
        [Display(Name = "Giá trị tồn kho")]
        public decimal StockValue
        {
            get
            {
                return Price * Quantity;
            }
        }
    }
}
