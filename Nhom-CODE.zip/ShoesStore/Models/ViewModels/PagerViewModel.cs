namespace ShoesStore.Models.ViewModels
{
    public class PagerViewModel
    {
        public int PageIndex { get; set; }

        public int TotalPages { get; set; }

        public int TotalCount { get; set; }

        public int FirstItemIndex { get; set; }

        public int LastItemIndex { get; set; }

        public string ActionName { get; set; } = "Index";

        public string ControllerName { get; set; } = string.Empty;

        public Dictionary<string, string?> RouteValues { get; set; } = new Dictionary<string, string?>();

        public bool HasPreviousPage
        {
            get
            {
                return PageIndex > 1;
            }
        }

        public bool HasNextPage
        {
            get
            {
                return PageIndex < TotalPages;
            }
        }

        public Dictionary<string, string?> BuildRouteValues(int pageNumber)
        {
            Dictionary<string, string?> values = new Dictionary<string, string?>(RouteValues);
            values["pageNumber"] = pageNumber.ToString();
            return values;
        }
    }
}
