namespace ShoesStore.Models.ViewModels
{
    public class HomeViewModel
    {
        public int TotalProducts { get; set; }

        public int TotalCategories { get; set; }

        public int TotalQuantity { get; set; }

        public decimal TotalInventoryValue { get; set; }

        public List<Product> LatestProducts { get; set; } = new List<Product>();
    }
}
