using Microsoft.AspNetCore.Mvc.Rendering;

namespace ShoesStore.Models.ViewModels
{
    public class ProductIndexViewModel
    {
        public PaginatedList<Product> Products { get; set; } = new PaginatedList<Product>(new List<Product>(), 0, 1, 5);

        public string? SearchString { get; set; }

        public int? CategoryId { get; set; }

        public decimal? MinPrice { get; set; }

        public decimal? MaxPrice { get; set; }

        public string? SortOrder { get; set; }

        public SelectList? Categories { get; set; }

        public SelectList? SortOptions { get; set; }

        public Dictionary<string, string?> GetRouteValues()
        {
            Dictionary<string, string?> routeValues = new Dictionary<string, string?>();

            if (!string.IsNullOrWhiteSpace(SearchString))
            {
                routeValues["searchString"] = SearchString;
            }

            if (CategoryId.HasValue && CategoryId.Value > 0)
            {
                routeValues["categoryId"] = CategoryId.Value.ToString();
            }

            if (MinPrice.HasValue)
            {
                routeValues["minPrice"] = MinPrice.Value.ToString("0");
            }

            if (MaxPrice.HasValue)
            {
                routeValues["maxPrice"] = MaxPrice.Value.ToString("0");
            }

            if (!string.IsNullOrWhiteSpace(SortOrder))
            {
                routeValues["sortOrder"] = SortOrder;
            }

            return routeValues;
        }
    }
}
