using System.ComponentModel.DataAnnotations;

namespace ShoesStore.Models.ViewModels
{
    public class CategoryStatisticViewModel
    {
        public int CategoryId { get; set; }

        [Display(Name = "Danh mục")]
        public string CategoryName { get; set; } = string.Empty;

        [Display(Name = "Số mẫu sản phẩm")]
        public int ProductCount { get; set; }

        [Display(Name = "Tổng số lượng tồn")]
        public int TotalQuantity { get; set; }

        [Display(Name = "Giá trị tồn kho")]
        public decimal TotalValue { get; set; }

        [Display(Name = "Tỷ lệ giá trị (%)")]
        public double ValuePercent { get; set; }
    }

    public class StatisticsViewModel
    {
        [Display(Name = "Tổng số sản phẩm")]
        public int TotalProducts { get; set; }

        [Display(Name = "Tổng số danh mục")]
        public int TotalCategories { get; set; }

        [Display(Name = "Tổng số lượng tồn")]
        public int TotalQuantity { get; set; }

        [Display(Name = "Tổng giá trị tồn kho")]
        public decimal TotalInventoryValue { get; set; }

        [Display(Name = "Giá bán trung bình")]
        public decimal AveragePrice { get; set; }

        public int LowStockThreshold { get; set; }

        public List<CategoryStatisticViewModel> CategoryStatistics { get; set; } = new List<CategoryStatisticViewModel>();

        public List<Product> LowStockProducts { get; set; } = new List<Product>();
    }
}
