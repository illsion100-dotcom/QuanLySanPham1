using Microsoft.EntityFrameworkCore;

namespace ShoesStore.Models
{
    public class PaginatedList<T> : List<T>
    {
        public int PageIndex { get; private set; }

        public int TotalPages { get; private set; }

        public int TotalCount { get; private set; }

        public int PageSize { get; private set; }

        public PaginatedList(List<T> items, int count, int pageIndex, int pageSize)
        {
            PageIndex = pageIndex;
            PageSize = pageSize;
            TotalCount = count;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            AddRange(items);
        }

        public bool HasPreviousPage
        {
            get
            {
                return PageIndex > 1;
            }
        }

        public bool HasNextPage
        {
            get
            {
                return PageIndex < TotalPages;
            }
        }

        public int FirstItemIndex
        {
            get
            {
                return TotalCount == 0 ? 0 : ((PageIndex - 1) * PageSize) + 1;
            }
        }

        public int LastItemIndex
        {
            get
            {
                return Math.Min(PageIndex * PageSize, TotalCount);
            }
        }

        public static async Task<PaginatedList<T>> CreateAsync(IQueryable<T> source, int pageIndex, int pageSize)
        {
            int count = await source.CountAsync();
            int totalPages = (int)Math.Ceiling(count / (double)pageSize);

            if (pageIndex < 1)
            {
                pageIndex = 1;
            }

            if (totalPages > 0 && pageIndex > totalPages)
            {
                pageIndex = totalPages;
            }

            List<T> items = await source
                .Skip((pageIndex - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return new PaginatedList<T>(items, count, pageIndex, pageSize);
        }
    }
}
