﻿document.addEventListener('DOMContentLoaded', function () {
    const fileInputs = document.querySelectorAll('input[type="file"][data-image-preview]');

    fileInputs.forEach(function (input) {
        input.addEventListener('change', function () {
            const previewSelector = input.getAttribute('data-image-preview');
            const previewImage = document.querySelector(previewSelector);

            if (!previewImage || !input.files || input.files.length === 0) {
                return;
            }

            const file = input.files[0];

            if (!file.type.startsWith('image/')) {
                return;
            }

            const reader = new FileReader();
            reader.onload = function (event) {
                previewImage.src = event.target.result;
            };
            reader.readAsDataURL(file);
        });
    });

    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alertElement) {
        setTimeout(function () {
            const alertInstance = bootstrap.Alert.getOrCreateInstance(alertElement);
            alertInstance.close();
        }, 6000);
    });
});
